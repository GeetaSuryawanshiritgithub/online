package com.online.system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineshoppingmanagementsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineshoppingmanagementsystemApplication.class, args);
	}


}
