package com.online.system.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.online.system.entity.online;
import com.online.system.repository.onlinerepository;
import com.online.system.service.onlineservice;

@Service
public class onlineserviceimpl implements onlineservice{
	
	private onlinerepository onlinerepo;

	public onlineserviceimpl(onlinerepository onlinerepo) {
		super();
		this.onlinerepo = onlinerepo;
	}
	
	@Override
	public List<online> getAllonline() {
		
		return onlinerepo.findAll();
	}
	
	@Override
	public online saveonline(online online) {
		
		return onlinerepo.save(online);
	}

	@Override
	public online getonlineById(int Srno) {
		
		return onlinerepo.findById(Srno).get();
	}

	@Override
	public void deleteonlineById(int Srno) {
		
		onlinerepo.deleteById(Srno);
		
	}
	
	

}
