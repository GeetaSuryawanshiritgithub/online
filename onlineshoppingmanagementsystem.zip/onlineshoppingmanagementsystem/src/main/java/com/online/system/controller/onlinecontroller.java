package com.online.system.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.online.system.entity.online;
import com.online.system.service.onlineservice;

@Controller
public class onlinecontroller {
	
	private onlineservice onlineser;

	public onlinecontroller(onlineservice onlineser) {
		super();
		this.onlineser = onlineser;
	}
	
	@GetMapping("/Getonline")
	public String Getonline (Model mod)
	{
		
		mod.addAttribute("online", onlineser.getAllonline());
		return "online";
	}
	
	
	
	//access insert form
	@GetMapping("/online/new")
	public String Createonline(Model mod)
	{
		online online = new online();
		mod.addAttribute("online" ,online);
		return "create_online";	
	}
	
	@PostMapping("/online/save")
	public String saveonline (@ModelAttribute("online") online online)
	{
		onlineser.saveonline(online);
		return "redirect:/Getonline";
	}
	
	@GetMapping("/online/edit/{id}")
	public String editonlineForm(@PathVariable int id, Model mod)
	{
		mod.addAttribute("online", onlineser.getonlineById(id));
		return "edit_online";
	}
	
	@PostMapping("/online/update/{id}")
	public String updateonline (@PathVariable int id ,@ModelAttribute("online") online onl , Model mod)
	{
		online existingO = onlineser.getonlineById(id);
		existingO.setSrno(id);
		existingO.setName(onl.getName());
		existingO.setCity(onl.getCity());
		existingO.setMobno(onl.getMobno());
		existingO.setProductName(onl.getProductName());
		existingO.setQuantity(onl.getQuantity());
		existingO.setPrice(onl.getPrice());
		existingO.setPaymentMode(onl.getPaymentMode());
		
		onlineser.saveonline(existingO);
		return "redirect:/Getonline";
	}
	
	
	@GetMapping("/online/delete/{Srno}")
	public String deletonline (@PathVariable int Srno )
	{
		onlineser.deleteonlineById(Srno);
		return "redirect:/Getonline";
	}
}


	
	

	
