package com.online.system.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="shop")
public class online {
	
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	private int Srno;
	
	@Column (name="Name" , nullable=false)
	private String Name;
	
	@Column (name=("City"))
	private String City;
	
	@Column (name=("Mobno"))
	private int Mobno;
	
	@Column (name=("ProductName"))
	private String ProductName;
	
	@Column (name=("Quantity"))
	private int Quantity;
	
	@Column (name=("Price"))
	private int Price;
	
	@Column (name=("PaymentMode"))
	private String PaymentMode;

	
	public int getSrno() {
		return Srno;
	}


	public void setSrno(int srno) {
		Srno = srno;
	}


	public String getName() {
		return Name;
	}


	public void setName(String name) {
		Name = name;
	}


	public String getCity() {
		return City;
	}


	public void setCity(String city) {
		City = city;
	}


	public int getMobno() {
		return Mobno;
	}


	public void setMobno(int mobno) {
		Mobno = mobno;
	}


	public String getProductName() {
		return ProductName;
	}


	public void setProductName(String productName) {
		ProductName = productName;
	}


	public int getQuantity() {
		return Quantity;
	}


	public void setQuantity(int quantity) {
		Quantity = quantity;
	}


	public int getPrice() {
		return Price;
	}


	public void setPrice(int price) {
		Price = price;
	}


	public String getPaymentMode() {
		return PaymentMode;
	}


	public void setPaymentMode(String paymentMode) {
		PaymentMode = paymentMode;
	}


	public online(String name, String city, int mobno, String productName, int quantity, int price,
			String paymentMode) {
		super();
		Name = name;
		City = city;
		Mobno = mobno;
		ProductName = productName;
		Quantity = quantity;
		Price = price;
		PaymentMode = paymentMode;
	}


	public online() {
		
	}

}


