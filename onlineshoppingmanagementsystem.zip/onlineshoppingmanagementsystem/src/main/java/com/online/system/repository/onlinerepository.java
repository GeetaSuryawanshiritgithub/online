package com.online.system.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.online.system.entity.online;

public interface onlinerepository extends JpaRepository<online, Integer> {

}
