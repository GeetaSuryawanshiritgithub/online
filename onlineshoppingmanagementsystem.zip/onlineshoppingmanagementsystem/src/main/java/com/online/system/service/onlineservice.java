package com.online.system.service;

import java.util.List;

import com.online.system.entity.online;

public interface onlineservice {

	List<online> getAllonline();

	online saveonline(online online);

	online getonlineById(int Srno);

	void deleteonlineById(int Srno);

	

}
